/**
 * 
 */
package com.capg.airline.bean;

/**
 * @author CAPG
 *
 */
public class FlightInformation {

	/**
	 * 
	 */

	private String flightNo;
	private String airline;
	private String depCity;
	private String arrCity;
	private String depDate;
	private String arrDate;
	private String depTime;
	private String arrTime;
	private int firstSeats;
	private double firstSeatFare;
	private int bussSeats;
	private double bussSeatsFare;

	/**
	 * @return the flightNo
	 */
	public String getFlightNo() {
		return flightNo;
	}

	/**
	 * @param flightNo
	 *            the flightNo to set
	 */
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	/**
	 * @return the airline
	 */
	public String getAirline() {
		return airline;
	}

	/**
	 * @param airline
	 *            the airline to set
	 */
	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDepDate() {
		return depDate;
	}

	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}

	public String getArrDate() {
		return arrDate;
	}

	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}

	/**
	 * @return the depCity
	 */
	public String getDepCity() {
		return depCity;
	}

	/**
	 * @param depCity
	 *            the depCity to set
	 */
	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}

	/**
	 * @return the arrCity
	 */
	public String getArrCity() {
		return arrCity;
	}

	/**
	 * @param arrCity
	 *            the arrCity to set
	 */
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}

	/**
	 * @return the depDate
	 */

	/**
	 * @return the depTime
	 */
	public String getDepTime() {
		return depTime;
	}

	/**
	 * @param depTime
	 *            the depTime to set
	 */
	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}

	/**
	 * @return the arrTime
	 */
	public String getArrTime() {
		return arrTime;
	}

	/**
	 * @param arrTime
	 *            the arrTime to set
	 */
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}

	/**
	 * @return the firstSeats
	 */
	public int getFirstSeats() {
		return firstSeats;
	}

	/**
	 * @param firstSeats
	 *            the firstSeats to set
	 */
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}

	/**
	 * @return the firstSeatFare
	 */
	public double getFirstSeatFare() {
		return firstSeatFare;
	}

	/**
	 * @param firstSeatFare
	 *            the firstSeatFare to set
	 */
	public void setFirstSeatFare(double firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}

	/**
	 * @return the bussSeats
	 */
	public int getBussSeats() {
		return bussSeats;
	}

	/**
	 * @param bussSeats
	 *            the bussSeats to set
	 */
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}

	/**
	 * @return the bussSeatsFare
	 */
	public double getBussSeatsFare() {
		return bussSeatsFare;
	}

	/**
	 * @param bussSeatsFare
	 *            the bussSeatsFare to set
	 */
	public void setBussSeatsFare(double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}

	public FlightInformation() {
		// TODO Auto-generated constructor stub
	}

}
