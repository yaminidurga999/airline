/**
 * 
 */
package com.capg.airline.dao;

import com.capg.airline.bean.FlightInformation;

/**
 * @author CAPG
 *
 */
public interface IFlightInfoDao {

	public FlightInformation getAirplaneInfo(FlightInformation flightInformation);

	public FlightInformation fetchFlight(FlightInformation flightInformation);

	public FlightInformation addFlight();

	public FlightInformation deleteFlight(String FlightNo);

	public FlightInformation updateFlight(String flightNo);

}
