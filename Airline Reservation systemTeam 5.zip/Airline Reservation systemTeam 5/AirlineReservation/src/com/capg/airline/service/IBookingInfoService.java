/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.BookingInformation;
import com.capg.airline.bean.FlightInformation;

/**
 * @author CAPG
 *
 */
public interface IBookingInfoService {

	BookingInformation confirmBooking(BookingInformation bookingInformation, FlightInformation flightInformation);

	void displayBooking(BookingInformation bookingInformation);

	void cancelBooking(BookingInformation bookingInformation,FlightInformation flightInformation);

}
