/**
 * 
 */
package com.cpag.airline.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.NamingException;

import com.capg.airline.exception.AirlineException;

/**
 * @author CAPG
 *
 */
public class DBUtil {

	/**
	 * 
	 */
	public DBUtil() {
		// TODO Auto-generated constructor stub
	}

	public static Connection getConnection() throws NamingException, SQLException, AirlineException {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}
}
