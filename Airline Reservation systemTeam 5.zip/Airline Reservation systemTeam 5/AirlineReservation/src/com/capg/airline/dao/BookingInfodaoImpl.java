/**
 * 
 */
package com.capg.airline.dao;

import java.sql.Connection;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.naming.NamingException;

import com.capg.airline.bean.BookingInformation;
import com.capg.airline.bean.FlightInformation;
import com.capg.airline.exception.AirlineException;
import com.cpag.airline.util.DBUtil;

/**
 * @author CAPG
 *
 */
public class BookingInfodaoImpl implements IBookingInfoDao {

	Logger logger = Logger.getRootLogger();

	Connection connection;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	/**
	 * 
	 */
	public BookingInfodaoImpl() {
		// TODO Auto-generated constructor stub
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	//------------------------ 1.Airline Book --------------------------
	/*******************************************************************************************************
				 - Function Name	:	confirmBooking()
				 - Input Parameters	:   bookingInformation,flightInformation
				 - Return Type		:	AirportBean
				 - Throws		    :   AirlineException
				 - Author		    :   Team 5
				 - Creation Date	:	16/10/2017
				 - Description		:	booking tickets
	 ********************************************************************************************************/
	@Override
	public BookingInformation confirmBooking(BookingInformation bookingInformation,
			FlightInformation fligtInformation) {

		// int count=0;
		try {
			connection = DBUtil.getConnection();

			bookingInformation.setSeatNumber(fligtInformation.getFlightNo() + ((int) (Math.random() * 1000)));

			String query1 = "insert into bookinginformation values(?,?,?,?,?,?,?,?,?)";
			bookingInformation.setBookingId((int) (Math.random() * 10000) + "");
			// System.out.println((int)(Math.random()*10000)+"GGGGFGFGFGFFGGF");
			System.out.println("Your Booking Id is  " + bookingInformation.getBookingId());
			// System.out.println("Enter Source City");
			bookingInformation.setSrcCity(fligtInformation.getArrCity());
			// System.out.println("Enter Destination City");
			bookingInformation.setDestCity(fligtInformation.getDepCity());
			System.out.println("Enter your EmailId");
			String email = new Scanner(System.in).nextLine();
			bookingInformation.setCustEmaiil(email);
			System.out.println("Enter No. of passengers");
			int passengers = new Scanner(System.in).nextInt();
			bookingInformation.setNoOfPassengers(passengers);
			System.out.println("Enter Travelling Class");
			String classType = new Scanner(System.in).nextLine();
			bookingInformation.setClassType(classType);

			double totalFare = 0;
			String query2 = "";
			if (classType.equalsIgnoreCase("business")) {
				totalFare = bookingInformation.getNoOfPassengers() * fligtInformation.getBussSeatsFare();
				query2 = "Update flightinformation set BUSSSEATS="
						+ (fligtInformation.getBussSeats() - bookingInformation.getNoOfPassengers())
						+ " where airline='" + fligtInformation.getAirline() + "'";
				preparedStatement = connection.prepareStatement(query2);
				preparedStatement.executeUpdate();

			} else {
				totalFare = bookingInformation.getNoOfPassengers() * fligtInformation.getFirstSeatFare();
				query2 = "Update flightinformation set FIRSTSEATS="
						+ (fligtInformation.getFirstSeats() - bookingInformation.getNoOfPassengers())
						+ " where airline='" + fligtInformation.getAirline() + "'";
				preparedStatement = connection.prepareStatement(query2);
				preparedStatement.executeUpdate();

			}
			bookingInformation.setTotalFare(totalFare);
			System.out.println("Your Total Fare would be ----Rs." + bookingInformation.getTotalFare());
			System.out.println("Enter Credit Card no.");
			String creditCard = new Scanner(System.in).nextLine();
			bookingInformation.setCerditCardInfo(creditCard);

			preparedStatement = connection.prepareStatement(query1);
			preparedStatement.setString(1, bookingInformation.getBookingId());
			preparedStatement.setString(2, bookingInformation.getCustEmaiil());
			preparedStatement.setInt(3, bookingInformation.getNoOfPassengers());
			preparedStatement.setString(4, bookingInformation.getClassType());
			preparedStatement.setDouble(5, bookingInformation.getTotalFare());
			preparedStatement.setString(6, bookingInformation.getSeatNumber());
			preparedStatement.setString(7, bookingInformation.getCerditCardInfo());
			preparedStatement.setString(8, bookingInformation.getSrcCity());
			preparedStatement.setString(9, bookingInformation.getDestCity());
			preparedStatement.executeUpdate();
			System.out.println("Booking Confirmed, ThankYou\n\n");

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			logger.error("Not confirmed.");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Not confirmed.");

		} catch (Exception e) {

			logger.error("Not confirmed.");
		}
		return bookingInformation;
	}
	//------------------------ 1.Airline Book --------------------------
		/*******************************************************************************************************
					 - Function Name	:	displayBooking()
					 - Input Parameters	:   bookingInformation
					 - Return Type		:	AirportBean
					 - Throws		    :   AirlineException
					 - Author		    :   Team 5
					 - Creation Date	:	16/10/2017
					 - Description		:	displaying resepective booking
		 ********************************************************************************************************/
	@Override
	public void displayBooking(BookingInformation bookingInformation) {
		// TODO Auto-generated method stub
		String query = "select * from bookingInformation where booking_Id='" + bookingInformation.getBookingId() + "'";
		try {
			connection = DBUtil.getConnection();
			// System.out.println("tfhgfghfg");
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			// System.out.println("tfhgfghfg");

			resultSet.next();
			if (resultSet.getString(1) == null) {
				System.out.println("No Data Found for Booking ID " + bookingInformation.getBookingId());
				logger.error("No Data Found for given Booking ID");
			} else {
				System.out.println("Your Booking Information is as follows--");
				System.out.println(
						resultSet.getString(1) + "      " + resultSet.getString(2) + "         " + resultSet.getInt(3));
				System.out.println(resultSet.getString(4) + "      " + resultSet.getInt(5) + "           "
						+ resultSet.getString(6));
				System.out.println(resultSet.getString(7) + "      " + resultSet.getString(8) + "         "
						+ resultSet.getString(9));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("No Data Found for given Booking ID");

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			logger.error("No Data Found for given Booking ID");

		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			logger.error("No Data Found for given Booking ID");
		}

	}
	//------------------------ 1.Airline Book --------------------------
			/*******************************************************************************************************
						 - Function Name	:	cancelBooking()
						 - Input Parameters	:   bookingInformation,fligtInformation
						 - Return Type		:	AirportBean
						 - Throws		    :   AirlineException
						 - Author		    :   Team 5
						 - Creation Date	:	16/10/2017
						 - Description		:	cancel resepective booking
			 ********************************************************************************************************/
	@Override
	public void cancelBooking(BookingInformation bookingInformation,FlightInformation fligtInformation) {
		// TODO Auto-generated method stub

		String query = "delete from bookinginformation where booking_Id=?";
		try {
			connection = DBUtil.getConnection();
			// System.out.println("tfhgfghfg");
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bookingInformation.getBookingId());

			preparedStatement.executeUpdate();
			// System.out.println("tfhgfghfg");
			
			/*double totalFare = 0;
			String query2 = "";
			if (bookingInformation.getClassType().equalsIgnoreCase("business")) {
				fligtInformation.
				query2 = "Update flightinformation set BUSSSEATS="
						+ (fligtInformation.getBussSeats() - bookingInformation.getNoOfPassengers())
						+ " where airline='" + fligtInformation.getAirline() + "'";
				preparedStatement = connection.prepareStatement(query2);
				preparedStatement.executeUpdate();

			} else {
				totalFare = bookingInformation.getNoOfPassengers() * fligtInformation.getFirstSeatFare();
				query2 = "Update flightinformation set FIRSTSEATS="
						+ (fligtInformation.getFirstSeats() - bookingInformation.getNoOfPassengers())
						+ " where airline='" + fligtInformation.getAirline() + "'";
				preparedStatement = connection.prepareStatement(query2);
				preparedStatement.executeUpdate();

			}*/

			
			System.out.println("Booking Cancelled");
			logger.info("Booking Cancelled.");

		} catch (AirlineException | NamingException | SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Booking not cancelled.");

		}
	}
}
