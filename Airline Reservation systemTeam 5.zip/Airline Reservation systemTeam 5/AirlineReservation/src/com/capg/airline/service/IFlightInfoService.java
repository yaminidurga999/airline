/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.bean.UsersBean;

/**
 * @author CAPG
 *
 */
public interface IFlightInfoService {

	public FlightInformation getAirplaneInfo(FlightInformation flightInformation);

	public FlightInformation fetchFlight(FlightInformation flightInformation);

	public FlightInformation addFlight();

	public FlightInformation deleteFlight(String flightNo);

	public FlightInformation updateFlight(String flightNo);
}
