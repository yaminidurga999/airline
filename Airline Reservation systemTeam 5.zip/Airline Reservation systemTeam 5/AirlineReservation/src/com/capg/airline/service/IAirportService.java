/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.AirportBean;
import com.capg.airline.bean.FlightInformation;

/**
 * @author CAPG
 *
 */
public interface IAirportService {

	AirportBean fetchDetails(AirportBean airportBean,FlightInformation flightInformation);

	AirportBean occupancyDetails(AirportBean airportBean, FlightInformation flightInformation);

}
